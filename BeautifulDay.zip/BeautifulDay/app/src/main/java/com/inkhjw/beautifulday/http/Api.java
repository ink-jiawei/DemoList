package com.inkhjw.beautifulday.http;

/**
 * @author hjw
 * @deprecated
 */
public class Api {
    public static final String HTTP_HOST = "http://192.168.1.102:8080/BeautifulDayWeb/";

    public static final String USER_LOGIN = HTTP_HOST + "login";
}
