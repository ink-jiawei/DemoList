package com.sun.bookread.http;

/**
 * author:何佳伟
 * 处理请求数据的回调接口
 */
public interface IOAuthCallBack {
    void getIOAuthCallBack(String s);
}
